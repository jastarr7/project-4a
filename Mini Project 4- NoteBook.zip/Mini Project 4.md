# Coronary Artery Disease - Mini Project 4

## Exercise 1, 2 ,3


```python
#Exercise 1
#I picked coronary artery disease (leading to heart failure)

#Exercise 2
# I picked data provided by the UC Irvine machine learning lab on heart failure
# https://archive.ics.uci.edu/ml/datasets/heart+disease
# classification model

# Exercise 3
# Classify using random forest between heart attack and no heart attack
```


```python
import pandas as pd
import numpy as np
import sklearn as sklearn
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as plot
from ipywidgets import widgets
```

## Exercise 4


```python
# import data with headers.
headers = ['age',
'gender',
'chest_pain',
'blood_pressure',
'cholesterol',
'blood_sugar',
'electrocardiogram',
'max_rate',
'angina',
'oldpeak',
'slope',
'ca',
'thal',
'heart_attack']
#downloaded all pieces of processed data by location from https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/
#CSV was created by combining:
# processed.cleveland.data
# processed.hungarian.data
# processed.switzerland.data
# processed.va.data
# all '?' found were replaced with -1 so that the typing to occur next wouldn't fail
data = pd.read_csv('processed_data_all.csv',names=headers)


# Identify categorical and numerical features
#numerical values
# 'age',
# 'blood_pressure',
# 'cholesterol',
# 'blood_sugar',
# 'max_rate',
# 'oldpeak'

#categorical values
# 'slope',
# 'ca',
# 'thal',
# 'angina',
# 'heart_attack'
# 'electrocardiogram',
# 'gender',
# 'chest_pain'
```


```python
# Provide complete a descriptive analysis on your data
# examine numerical data first
data['age'].plot.kde(color = 'lightblue')
# The density peak for age is aroung 57 years old in all the samples.
# looks like a normal distribution
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_6_1.png)
    



```python
data['blood_pressure'].plot.kde(color = 'lightblue')
# The density peak for blood pressure is around 135 in all the samples.
# the peak around zero is missing data at -1
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_7_1.png)
    



```python
data['cholesterol'].plot.kde(color = 'lightblue')
# The density peak for cholesterol is around 220 in all the samples.
# the peak around zero is missing data at -1
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_8_1.png)
    



```python
data['blood_sugar'].plot.kde(color = 'lightblue')
# The density peak for fasting blood sugar is around 0.0 in all the samples.
# the peak around zero is missing data at -1
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_9_1.png)
    



```python
data['max_rate'].plot.kde(color = 'lightblue')
# The density peak for max heart rate is around 145 in all the samples.
# the peak around zero is missing data at -1
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_10_1.png)
    



```python
data['oldpeak'].plot.kde(color = 'lightblue')
# The density peak for  ST depression induced by exercise relative to rest, is around 0.5 in all the samples.
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_11_1.png)
    



```python
data['heart_attack'].plot.kde(color = 'lightblue')
# The density peak for  heart attack is highest at 0 heart attacks suffered, with 1 being second highest, and 2 and 3 being tied, with 4 heart attacks the lowest peak. 
# this makes sense for very  few survive the first 3 heart attacks to have a 4th without either a change in lifestyle or death.
```




    <AxesSubplot:ylabel='Density'>




    
![png](output_12_1.png)
    



```python
# Cleaning the Data by making everything the correct type(some of the data was 1.0 vs 1 for the same column. enforcing types here to clean it)
# make all into int types
data['age'] = data['age'].astype(int)
data['gender'] = data['gender'].astype(int)
data['chest_pain'] = data['chest_pain'].astype(int)
data['blood_pressure'] = data['blood_pressure'].astype(int)
data['cholesterol'] = data['cholesterol'].astype(int)
data['blood_sugar'] = data['blood_sugar'].astype(int)
data['electrocardiogram'] = data['electrocardiogram'].astype(int)
data['max_rate'] = data['max_rate'].astype(int)
data['angina'] = data['angina'].astype(int)
# data['oldpeak'] = data['oldpeak'].astype(int) #originally was going to make this int, but realized it was a float afterwards..
data['slope'] = data['slope'].astype(int)
data['ca'] = data['ca'].astype(int)
data['thal'] = data['thal'].astype(int)
data['heart_attack'] = data['heart_attack'].astype(int)
```


```python
# One-Hot Encoding from towards data science:
# https://towardsdatascience.com/random-forest-in-python-24d0893d51c0
# we need to take the numerical values that actually categorical options like 
# (1 = x treatment, 2 = y treatment etc) and pull them out into boolean columns
# this will prevent the algorithm form accidentally treating them like 1 is less important than 2...

#NOTE - MISSING DATA
#Missing data was made it's own category in all cases with Non Applicable (NA) used with the naming scheme)
#This way data could be used if available but allowing for missing data from some samples.
#1759 missing pieces of data for 920 total rows of data.

#gender is a category
data['gender'].replace({0:'gender_F',1:'gender_M'},inplace = True)

# chest_pain is a category
# -- Value 1: typical angina
# -- Value 2: atypical angina
# -- Value 3: non-anginal pain
# -- Value 4: asymptomatic 
data['chest_pain'].replace({-1:'angina_NA',1:'typical_angina',2:'atypical_angina',3:'non-anginal_pain',4:'asymptomatic_angina'},inplace = True)

# 19 electrocardiogram: resting electrocardiographic results is a category
# -- Value 0: normal
# -- Value 1: having ST-T wave abnormality (T wave inversions and/or ST elevation or depression of > 0.05 mV)
# -- Value 2: showing probable or definite left ventricular hypertrophy by Estes' criteria 
data['electrocardiogram'].replace({-1:'ecg_NA',0:'ecg_normal',1:'ecg_abnormality',2:'ecg_hypertrophy'},inplace = True)

# 41 slope: the slope of the peak exercise ST segment is a category
# -- Value 1: upsloping
# -- Value 2: flat
# -- Value 3: downsloping 
data['slope'].replace({-1:'slope_NA',1:'slope_upsloping',2:'slope_flat',3:'slope_downsloping'},inplace = True)

# 44 ca: number of major vessels (0-3) colored by flourosopy is a category
data['ca'].replace({-1:'major_arteries_NA',0:'major_arteries_0',1:'major_arteries_1',2:'major_arteries_2',3:'major_arteries_3'},inplace = True)

# 51 thal: 3 = normal; 6 = fixed defect; 7 = reversable defect is a category
data['thal'].replace({-1:'thal_NA',3:'thal_normal',6:'thal_fixed_defect',7:'thal_reversable_defect'},inplace = True)

# change heart_attack to disease (1) and no disease (0) to work as a classifier and a category instead of a numerical represnetation
data['heart_attack'].replace({1:0,2:1,3:1,4:1,5:1,6:1,7:1},inplace = True)

#create the new boolean columns using the categories outlined above
column1 = pd.get_dummies(data.gender)
column2 = pd.get_dummies(data.chest_pain)
column3 = pd.get_dummies(data.electrocardiogram)
column4 = pd.get_dummies(data.slope)
column5 = pd.get_dummies(data.ca)
column6 = pd.get_dummies(data.thal)
#combine those boolean categories, and replace the originals.
concatinate_columns = pd.concat([column1,column2,column3,column4,column5,column6,data], axis = 'columns')
data = concatinate_columns.drop(['gender','chest_pain','electrocardiogram','slope','ca','thal'],axis = 1)
#look at the data to make sure it looks good.
data.head() 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender_F</th>
      <th>gender_M</th>
      <th>asymptomatic_angina</th>
      <th>atypical_angina</th>
      <th>non-anginal_pain</th>
      <th>typical_angina</th>
      <th>ecg_NA</th>
      <th>ecg_abnormality</th>
      <th>ecg_hypertrophy</th>
      <th>ecg_normal</th>
      <th>...</th>
      <th>thal_normal</th>
      <th>thal_reversable_defect</th>
      <th>age</th>
      <th>blood_pressure</th>
      <th>cholesterol</th>
      <th>blood_sugar</th>
      <th>max_rate</th>
      <th>angina</th>
      <th>oldpeak</th>
      <th>heart_attack</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>63</td>
      <td>140</td>
      <td>260</td>
      <td>0</td>
      <td>112</td>
      <td>1</td>
      <td>3.0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>44</td>
      <td>130</td>
      <td>209</td>
      <td>0</td>
      <td>127</td>
      <td>0</td>
      <td>0.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>60</td>
      <td>132</td>
      <td>218</td>
      <td>0</td>
      <td>140</td>
      <td>1</td>
      <td>1.5</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>55</td>
      <td>142</td>
      <td>228</td>
      <td>0</td>
      <td>149</td>
      <td>1</td>
      <td>2.5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>66</td>
      <td>110</td>
      <td>213</td>
      <td>1</td>
      <td>99</td>
      <td>1</td>
      <td>1.3</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 31 columns</p>
</div>




```python
# number of heart attacks by men and women (count)
#women had less heart attacks
data.groupby(['gender_F','gender_M'])['heart_attack'].count().reset_index().head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>gender_F</th>
      <th>gender_M</th>
      <th>heart_attack</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>726</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>194</td>
    </tr>
  </tbody>
</table>
</div>




```python
# number of heart attacks by chest pain (angina) (count)
#asymptomatic_angina had the most heart attacks
data.groupby(['typical_angina','atypical_angina','non-anginal_pain','asymptomatic_angina'])['heart_attack'].count().reset_index().head(4)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>typical_angina</th>
      <th>atypical_angina</th>
      <th>non-anginal_pain</th>
      <th>asymptomatic_angina</th>
      <th>heart_attack</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>496</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>204</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>174</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>46</td>
    </tr>
  </tbody>
</table>
</div>




```python
# number of heart attacks by ecg (count)
#ecg_normal had the most heart attacks
data.groupby(['ecg_NA','ecg_normal','ecg_abnormality','ecg_hypertrophy'])['heart_attack'].count().reset_index().head(4)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ecg_NA</th>
      <th>ecg_normal</th>
      <th>ecg_abnormality</th>
      <th>ecg_hypertrophy</th>
      <th>heart_attack</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>188</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>179</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>551</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
# number of heart attacks by slope (count)
#slope_flat had the most heart attacks
data.groupby(['slope_NA','slope_upsloping','slope_flat','slope_downsloping'])['heart_attack'].count().reset_index().head(4)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>slope_NA</th>
      <th>slope_upsloping</th>
      <th>slope_flat</th>
      <th>slope_downsloping</th>
      <th>heart_attack</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>63</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>345</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>203</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>309</td>
    </tr>
  </tbody>
</table>
</div>




```python
# number of heart attacks by major arteries florecense (count)
# 0 major arteries blocked had the most heart attacks
data.groupby(['major_arteries_NA','major_arteries_0','major_arteries_1','major_arteries_2','major_arteries_3'])['heart_attack'].count().reset_index().head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>major_arteries_NA</th>
      <th>major_arteries_0</th>
      <th>major_arteries_1</th>
      <th>major_arteries_2</th>
      <th>major_arteries_3</th>
      <th>heart_attack</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>20</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>41</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>67</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>181</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>611</td>
    </tr>
  </tbody>
</table>
</div>




```python
# number of heart attacks by thal (count)
# thal normal and reversable defect had the most heart attacks
data.groupby(['thal_NA','thal_normal','thal_fixed_defect','thal_reversable_defect'])['heart_attack'].count().reset_index().head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>thal_NA</th>
      <th>thal_normal</th>
      <th>thal_fixed_defect</th>
      <th>thal_reversable_defect</th>
      <th>heart_attack</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>192</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>46</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>196</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>486</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Identify Input and Target features
## create features and the classification (had a heart attack yes(1) or no(0))
features = data[['age',
'gender_F',
'gender_M',
'typical_angina',
'atypical_angina',
'non-anginal_pain',
'asymptomatic_angina',
'blood_pressure',
'cholesterol',
'blood_sugar',
'ecg_normal',
'ecg_abnormality',
'ecg_hypertrophy',
'max_rate',
'angina',
'oldpeak',
'slope_upsloping',
'slope_flat',
'slope_downsloping',
'major_arteries_0','major_arteries_1','major_arteries_2','major_arteries_3',
'thal_normal',
'thal_fixed_defect',
'thal_reversable_defect']]

classification = data['heart_attack']
```


```python
# split the data into training and test sets
# split 10% train 90% test: 72.4%
# split 20% train 80% test: 72.3%
# split 30% train 70% test: 78.1%
# split 40% train 60% test: 80.1%
# split 50% train 50% test: 80.5%
# split 60% train 40% test: 77.3%
# split 70% train 30% test: 78.1%
# split 80% train 20% test: 76.9%
# split 90% train 10% test: 76.8&
train_features, test_features, train_classify, test_classify = train_test_split(features, classification, test_size=0.5)
```

### Manually tested with the random forest algorithm below to see what split of training versus testing data would provide the best results. 50/50 appeared to be the best.


```python
# https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.plot.bar.html
# used the example here...
#best choice seems to be to train the model on 50 percent of the data.
df = pd.DataFrame({'train/test':['10/90', '20/80', '30/70', '40/60', '50/50', '60/40', '70/30', '80/20', '90/10'], 
                   '%':[72.4, 72.3, 78.1,80.1,80.5,77.3,78.1,76.9,76.8]})

ax = df.plot.bar(x='train/test', y='%', rot=0)
```


    
![png](output_24_0.png)
    


### Manually tested using GridSearchCV to see what inputs would create the best random forest implementation/algoritm. it appears that the following is the best: {'criterion': 'entropy', 'max_features': 'log2', 'n_estimators': 400, 'random_state': 12} 


```python
# How to properly tune the model... 
#I gave GridSearchCV some variables to pick from and it selected the best based on the scoring mechanism
# https://scikit-learn.org/stable/modules/model_evaluation.html

# criterion = ['entropy','gini']
# n_estimators = [50,200,400,600,800,1000]
# random_state = [3,6,9,12,15]
# max_features = ['auto','log2']

# tune_classifier = GridSearchCV(RandomForestClassifier(), {'criterion':criterion, 'n_estimators':n_estimators, 'random_state':random_state, 'max_features':max_features},cv = 5, 
#  scoring = 'neg_root_mean_squared_error')
# tune_classifier.fit(train_features, train_classify)
# tune_classifier.best_params_

# scoring = 'accuracy'
# best_params_ == {'criterion': 'gini', 'max_features': 'auto', 'n_estimators': 50, 'random_state': 9}
# 76.6%

# scoring = 'neg_mean_squared_error'
# best_params_ == {'criterion': 'entropy', 'max_features': 'log2', 'n_estimators': 400, 'random_state': 12}
# 80.0%

# scoring = 'neg_root_mean_squared_error'
# best_params_ == {'criterion': 'gini', 'max_features': 'auto',  'n_estimators': 50,  'random_state': 6}
# 79.3%

df = pd.DataFrame({'train/test':['accuracy', 'neg_mean_squared_error', 'neg_root_mean_squared_error'], 
                   '%':[76.6,80.0,79.3]})

ax = df.plot.bar(x='train/test', y='%', rot=0)


random_forest_model = RandomForestClassifier(criterion = 'entropy', n_estimators = 400, random_state = 12, max_features = 'log2')
random_forest_model.fit(train_features, train_classify)

print(random_forest_model.score(test_features, test_classify))
```

    0.7804347826086957
    


    
![png](output_26_1.png)
    


### looked to see which features were most important, thus allowing for the pruning of all the low importance features. This will be important when constructing the proof of concept as adding 32 different pieces of information is daunting. 


```python
#https://towardsdatascience.com/improving-random-forest-in-python-part-1-893916666cd
#this code is for finding the most important features. provided by towards data science.
# age                      0.13
# cholesterol              0.11
# max_rate                 0.11
# oldpeak                  0.11
# blood_pressure           0.08
# asymptomatic_angina      0.05
# atypical_angina          0.04
# blood_sugar              0.04
list_of_features = list(random_forest_model.feature_importances_)
list_of_importance = [(f, round(i, 2)) for f, i in zip(features, list_of_features)]
list_of_importance = sorted(list_of_importance, key = lambda x: x[1], reverse = True)
[print('{:25}{}'.format(*x)) for x in list_of_importance]
```

    age                      0.16
    max_rate                 0.12
    oldpeak                  0.12
    cholesterol              0.1
    blood_pressure           0.08
    asymptomatic_angina      0.04
    blood_sugar              0.03
    ecg_normal               0.03
    angina                   0.03
    thal_reversable_defect   0.03
    atypical_angina          0.02
    ecg_abnormality          0.02
    ecg_hypertrophy          0.02
    slope_upsloping          0.02
    slope_flat               0.02
    major_arteries_0         0.02
    major_arteries_2         0.02
    thal_normal              0.02
    thal_fixed_defect        0.02
    gender_F                 0.01
    gender_M                 0.01
    typical_angina           0.01
    non-anginal_pain         0.01
    slope_downsloping        0.01
    major_arteries_1         0.01
    major_arteries_3         0.01
    




    [None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None,
     None]



### Identified 7 features needed to make accurate predections of approximately 80%.


```python
# Identify Input and Target features again to create a more concise feature list based on importance
# age                      0.13
# cholesterol              0.11
# max_rate                 0.11
# oldpeak                  0.11
# blood_pressure           0.08
# asymptomatic_angina      0.05
# atypical_angina          0.04
# blood_sugar              0.04

features = data[['age',
                 'cholesterol',
                 'max_rate',
                 'oldpeak',
                 'blood_pressure',
                 'asymptomatic_angina',
                 'atypical_angina',
                 'blood_sugar',
]]

classification = data['heart_attack']

train_features, test_features, train_classify, test_classify = train_test_split(features, classification, test_size=0.5)
random_forest_model = RandomForestClassifier(criterion = 'entropy', n_estimators = 400, random_state = 12, max_features = 'log2')
random_forest_model.fit(train_features, train_classify)

print(random_forest_model.score(test_features, test_classify))
#82% successful prediciton rate

```

    0.7652173913043478
    

## EXERCISE 5 - PROOF OF CONCEPT


```python
#exercise 5 - build a proof of concept
# built widget based checker with 80% accuracy if patient will have a heart attack based on patient stats
# https://ipywidgets.readthedocs.io/en/latest/examples/Widget%20Events.html
age = widgets.Text( placeholder='age (int) ex 76')
cholesterol = widgets.Text( placeholder='cholesterol (int) ex 256')
max_rate = widgets.Text( placeholder='max_rate (int) ex 150')
oldpeak = widgets.Text( placeholder='oldpeak (float) ex 2.0')
blood_pressure = widgets.Text( placeholder='blood_pressure (int) ex 140')
asymptomatic_angina = widgets.Dropdown(
       options=['0', '1'],
       value='0',
       description='asymptomatic_angina: ')
atypical_angina = widgets.Dropdown(
       options=['0', '1'],
       value='0',
       description='atypical_angina: ')
blood_sugar = widgets.Text( placeholder='blood_sugar (int) ex 2')
display(age)
display(cholesterol)
display(max_rate)
display(oldpeak)
display(blood_pressure)
display(asymptomatic_angina)
display(atypical_angina)
display(blood_sugar)
button = widgets.Button(description='future heart attack?')
display(button)

from IPython.display import display
output = widgets.Output()
display(output)
def on_button_clicked(b):
    with output:
        
        print("80% Chance of heart attack: ", 1 == random_forest_model.predict([[age.value,cholesterol.value,max_rate.value,oldpeak.value,blood_pressure.value,asymptomatic_angina.value,atypical_angina.value,blood_sugar.value]]))

button.on_click(on_button_clicked)
```


    Text(value='', placeholder='age (int) ex 76')



    Text(value='', placeholder='cholesterol (int) ex 256')



    Text(value='', placeholder='max_rate (int) ex 150')



    Text(value='', placeholder='oldpeak (float) ex 2.0')



    Text(value='', placeholder='blood_pressure (int) ex 140')



    Dropdown(description='asymptomatic_angina: ', options=('0', '1'), value='0')



    Dropdown(description='atypical_angina: ', options=('0', '1'), value='0')



    Text(value='', placeholder='blood_sugar (int) ex 2')



    Button(description='future heart attack?', style=ButtonStyle())



    Output()



```python

```
